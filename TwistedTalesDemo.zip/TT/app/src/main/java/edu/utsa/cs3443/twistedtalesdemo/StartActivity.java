package edu.utsa.cs3443.twistedtalesdemo;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class StartActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_start);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        Button btnNewGame = findViewById(R.id.btnNewGame);
        btnNewGame.setOnClickListener(v ->
                startActivity(new Intent(this, StoryActivity.class)) // launch StoryActivity instead
        );

        Button btnHanselGretel = findViewById(R.id.btnContinueGame);
        btnHanselGretel.setOnClickListener(v -> {
            Intent intent = new Intent(this, MainActivity.class);
            // Inside your Activity or any other component
            String mostRecentSceneFile = CsvFileReader.readMostRecentSceneFile(this);
            if (mostRecentSceneFile != null) {
                intent.putExtra("scene_file", mostRecentSceneFile);
                startActivity(intent);
            } else {
                System.out.println("No scene file found or error reading log.");
            }

            //intent.putExtra("scene_file", mostRecentSceneFile); // Hansel and Gretel default
            startActivity(intent);
        });


    }
}
