package edu.utsa.cs3443.twistedtalesdemo;

import android.animation.ValueAnimator;
import android.content.Context;
import android.content.res.AssetManager;
import android.graphics.PorterDuffColorFilter;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import android.graphics.Color;
import android.graphics.PorterDuff;


/**
 * MainActivity handles the visual novel interface, displaying scenes, characters, dialogue,
 * and managing user interactions such as tapping, choosing branches, or entering input.
 */
public class MainActivity extends AppCompatActivity {

    // UI Components
    private SceneManager sceneManager;
    private ImageView backgroundImageView, mainIcon, otherIcon;
    private TextView nameTextView, dialogueTextView;
    private Button choiceButton1, choiceButton2;
    private EditText userInputEditText;
    private EditText userInputEditText1;
    private Button submitAnswerButton;
    private Button submitAnswerButton1;
    private RelativeLayout tapContainer;
    private ValueAnimator otherIconAnimator;




    // Typewriter effect variables
    private Handler textHandler = new Handler(); // Handles timed updates for typewriter effect
    private Runnable typeRunnable;
    private boolean isTyping = false;
    private int currentCharIndex = 0;
    private long typingSpeed = 30; // Typing delay per character in milliseconds
    private String fullTextToType = "";

    private boolean hasSubmittedHA439 = false; // Branching logic flag

    private List<String[]> choiceData = new ArrayList<>();  // Holds choices read from CSV

    /**
     * Initializes UI elements and begins the first scene.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Link UI components to layout
        backgroundImageView = findViewById(R.id.backgroundImageView);
        mainIcon = findViewById(R.id.mainIcon);
        otherIcon = findViewById(R.id.otherIcon);
        nameTextView = findViewById(R.id.nameTextView);
        dialogueTextView = findViewById(R.id.dialogueTextView);
        choiceButton1 = findViewById(R.id.choiceButton1);
        choiceButton2 = findViewById(R.id.choiceButton2);
        userInputEditText = findViewById(R.id.userInputEditText);
        userInputEditText1 = findViewById(R.id.userInputEditText1);
        submitAnswerButton = findViewById(R.id.submitAnswerButton);
        submitAnswerButton1 = findViewById(R.id.submitAnswerButton1);
        tapContainer = findViewById(R.id.tapContainer);

        // Initialize the sceneManager with a default scene
        sceneManager = new SceneManager(this, "HAGNeutral.csv");
        sceneManager = new SceneManager(this, "LHRNeutral.csv"); // This overrides the above (likely unintentional)

        // Check if another scene file was passed via intent
        String sceneFile = getIntent().getStringExtra("scene_file");
        if (sceneFile != null) {
            sceneManager.loadBranch(sceneFile);
        }

        showCurrentLine(); // Display the first line

        // Set tap behavior for progressing or branching
        tapContainer.setOnClickListener(v -> {
            SceneLine current = sceneManager.getCurrentLine();

            // If typewriter is in progress, complete it immediately
            if (isTyping) {
                skipTypewriter();
                return;
            }

            // Special case: user must choose between options in HA.02
            if (current != null && "HA.02".equals(current.sceneId) &&
                    "HAGNeutral.csv".equals(sceneManager.getCurrentFileName())) {
                showChoices();
                return;
            }

            // Special case: user must choose between options in HA.07
            if (current != null && "HA.07".equals(current.sceneId) &&
                    "HAGBranch1.csv".equals(sceneManager.getCurrentFileName())) {
                showChoices1();
                return;
            }

            // Wait for input on HA3.08
            if (current != null && "HA3.08".equals(current.sceneId)) {
                return;
            }

            // Show additional branching options
            if (current != null && "HA.34".equals(current.sceneId) &&
                    "HAGBranch1.csv".equals(sceneManager.getCurrentFileName())) {
                showChoices2();
                return;
            }

            // Require user input on HA4.39
            if (current != null && "HA4.39".equals(current.sceneId) && !hasSubmittedHA439) {
                return;
            }

            // Show LRH branching from choices CSV
            if (current != null && "LA.12".equals(current.sceneId) &&
                    "LRHNeutral.csv".equals(sceneManager.getCurrentFileName())) {
                showChoicesLRH();
                return;
            }

            // Show second LRH branching path
            if (current != null && "LA2.33".equals(current.sceneId) &&
                    "LRHBranch2.csv".equals(sceneManager.getCurrentFileName())) {
                showChoicesLRH1();
                return;
            }

            // Standard choice point handling
            if (sceneManager.isChoicePoint()) {
                sceneManager.waitForChoice();
                showChoices();
            } else {
                sceneManager.advanceScene();
                if (sceneManager.isAtEnd()) {
                    showEnding();
                } else {
                    showCurrentLine();
                }
            }
        });

        // Handle user input submission for HA4.39
        submitAnswerButton1.setOnClickListener(v -> {
            String userInput = userInputEditText1.getText().toString().trim();
            if (!userInput.isEmpty()) {
                hasSubmittedHA439 = true;
                userInputEditText1.setVisibility(View.GONE);
                submitAnswerButton1.setVisibility(View.GONE);
                sceneManager.advanceScene();
                showCurrentLine();
            }
        });
    }

    /**
     * Displays two buttons with choices and loads different scene branches depending on selection.
     */
    private void showChoices() {
        choiceButton1.setText("Good Idea!");
        choiceButton2.setText("Terrible Idea!");
        choiceButton1.setVisibility(View.VISIBLE);
        choiceButton2.setVisibility(View.VISIBLE);

        // Branch to HAGBranch2 on "Good Idea!"
        choiceButton1.setOnClickListener(v -> {
            sceneManager.loadBranch("HAGBranch2.csv");
            hideChoices();
            showCurrentLine();
        });

        // Branch to HAGBranch1 on "Terrible Idea!"
        choiceButton2.setOnClickListener(v -> {
            Log.d("MainActivity", "Loading HAGBranch1.csv");
            sceneManager.loadBranch("HAGBranch1.csv");
            hideChoices();
            showCurrentLine();
        });
    }

    /**
     * Displays HA.07 branching options with corresponding actions.
     */
    private void showChoices1() {
        choiceButton1.setText("Okay!");
        choiceButton2.setText("No Way!");
        choiceButton1.setVisibility(View.VISIBLE);
        choiceButton2.setVisibility(View.VISIBLE);

        choiceButton1.setOnClickListener(v -> {
            if (!"HAGBranch1.csv".equals(sceneManager.getCurrentFileName())) {
                sceneManager.loadBranch("HAGBranch1.csv");
            }
            hideChoices();
            sceneManager.advanceScene(); // Continue story instead of restarting
            showCurrentLine();
        });

        choiceButton2.setOnClickListener(v -> {
            Log.d("MainActivity", "Loading HAGBranch3.csv");
            sceneManager.loadBranch("HAGBranch3.csv");
            hideChoices();
            showCurrentLine();
        });
    }

    /**
     * Displays choices for HA.34 and loads appropriate branches.
     */
    private void showChoices2() {
        choiceButton1.setText("You’re right.");
        choiceButton2.setText("Absolutely Not!");
        choiceButton1.setVisibility(View.VISIBLE);
        choiceButton2.setVisibility(View.VISIBLE);

        choiceButton1.setOnClickListener(v -> {
            if (!"HAGBranch1.csv".equals(sceneManager.getCurrentFileName())) {
                sceneManager.loadBranch("HAGBranch1.csv");
            }
            hideChoices();
            sceneManager.advanceScene();
            showCurrentLine();
        });

        choiceButton2.setOnClickListener(v -> {
            Log.d("MainActivity", "Loading HAGBranch4.csv");
            sceneManager.loadBranch("HAGBranch4.csv");
            hideChoices();
            showCurrentLine();
        });
    }

    /**
     * Shows LRH choices loaded from a CSV file (LRHChoices.csv).
     */
    private void showChoicesLRH() {
        loadChoicesFromFile("LRHChoices.csv", this);

        if (choiceData.size() >= 2) {
            String choice1Text = choiceData.get(0)[1];
            String choice2Text = choiceData.get(1)[1];
            String branch1 = choiceData.get(0)[2];
            String branch2 = choiceData.get(1)[2];

            choiceButton1.setText(choice1Text);
            choiceButton2.setText(choice2Text);
            choiceButton1.setVisibility(View.VISIBLE);
            choiceButton2.setVisibility(View.VISIBLE);

            choiceButton1.setOnClickListener(v -> {
                sceneManager.loadBranch(branch1);
                hideChoices();
                showCurrentLine();
            });

            choiceButton2.setOnClickListener(v -> {
                sceneManager.loadBranch(branch2);
                hideChoices();
                showCurrentLine();
            });
        }
    }

    /**
     * Handles second pair of choices for LRH branch (from rows 3 and 4 in the CSV).
     */
    public void showChoicesLRH1() {
        Log.d("SceneManager", "showChoicesLRH1() method called");

        if (choiceData.size() >= 4) {
            String choice1Text = choiceData.get(2)[1];
            String choice2Text = choiceData.get(3)[1];
            String branch3 = choiceData.get(2)[2];
            String branch4 = choiceData.get(3)[2];

            choiceButton1.setText(choice1Text);
            choiceButton2.setText(choice2Text);
            choiceButton1.setVisibility(View.VISIBLE);
            choiceButton2.setVisibility(View.VISIBLE);

            choiceButton1.setOnClickListener(v -> {
                Log.d("SceneManager", "Loading branch: " + branch3);
                sceneManager.loadBranch(branch3);
                hideChoices();
                showCurrentLine();
            });

            choiceButton2.setOnClickListener(v -> {
                Log.d("SceneManager", "Loading branch: " + branch4);
                sceneManager.loadBranch(branch4);
                hideChoices();
                showCurrentLine();
            });
        } else {
            Log.e("SceneManager", "Insufficient data in choiceData for LRH choices");
        }
    }

    /**
     * Displays the final line and disables further input when story ends.
     */
    private void showEnding() {
        nameTextView.setText("");
        dialogueTextView.setText("The End. Thanks for playing!");
        mainIcon.setVisibility(View.GONE);
        otherIcon.setVisibility(View.GONE);
        userInputEditText.setVisibility(View.GONE);
        submitAnswerButton.setVisibility(View.GONE);
        tapContainer.setOnClickListener(null); // Disable further tapping
    }

    /**
     * Displays name, dialogue, and associated images for the current line.
     */
    private void showCurrentLine() {
        SceneLine line = sceneManager.getCurrentLine();
        if (line == null) return;

        nameTextView.setText(line.name);
        startTypewriterEffect(line.dialogue);
        setImage(backgroundImageView, line.background);
        setImage(mainIcon, line.mainIcon);
        setImage(otherIcon, line.otherIcon);

        // Flip second character image to face left
        mainIcon.setScaleX(1f);
        otherIcon.setScaleX(-1f);

        // GLOWING EFFECT FOR HA.36
        if (line.sceneId.startsWith("HA.36") && "HAGBranch1.csv".equals(sceneManager.getCurrentFileName())) {
            if (line.name != null && !line.name.trim().equalsIgnoreCase("Witch")) {
                applyGlowingRedEffect(mainIcon, 0f);
                applyGlowingRedEffect(otherIcon, 0f);
                fadeInGlowEffect(mainIcon);
                fadeInGlowEffect(otherIcon);
            }
        }

        if (line.sceneId.startsWith("HA.38") && "HAGBranch1.csv".equals(sceneManager.getCurrentFileName())) {
            Log.d("DEBUG", "Clearing glow effect for otherIcon at scene: " + line.sceneId);
            if (otherIconAnimator != null) {
                otherIconAnimator.cancel();  // Cancel the animation before clearing
            }
            otherIcon.clearColorFilter();
        }

        // Show input field for scene HA3.08
        if ("HA3.08".equals(line.sceneId)) {
            showInputPrompt();
        } else {
            hideInputPrompt();
        }

        // Show input field for scene HA4.39
        if ("HA4.39".equals(line.sceneId)) {
            showInputPrompt1();
        } else {
            hideInputPrompt1();
        }
    }

    /**
     * Applies a reddish-orange glowing color effect with the given opacity to the provided ImageView.
     * @param imageView The ImageView to apply the glowing effect to.
     * @param alpha The opacity level of the glow effect (0f to 1f).
     */
    private void applyGlowingRedEffect(ImageView imageView, float alpha) {
        int redColor = Color.parseColor("#FF4500"); // Reddish-orange
        // 50% opacity
        int glowColor = Color.argb((int)(alpha * 128), Color.red(redColor), Color.green(redColor), Color.blue(redColor)); // Adjust alpha for transparency
        PorterDuffColorFilter filter = new PorterDuffColorFilter(glowColor, PorterDuff.Mode.SRC_ATOP);
        imageView.setColorFilter(filter);
    }

    /**
     * Fades in the glowing effect for the provided ImageView.
     * @param imageView The ImageView to apply the glowing effect to.
     */
    private void fadeInGlowEffect(ImageView imageView) {
        // Cancel any existing animation
        if (imageView == otherIcon && otherIconAnimator != null) {
            otherIconAnimator.cancel();
        }

        ValueAnimator animator = ValueAnimator.ofFloat(0f, 1f);
        animator.setDuration(5000); // Slow 5 second fade-in
        animator.addUpdateListener(animation -> {
            float animatedFraction = (float) animation.getAnimatedValue();

            // Interpolate from alpha 0 (fully transparent) to 136 (0x88)
            int alpha = (int)(136 * animatedFraction); // 136 = 0x88
            int glowingRed = Color.argb(alpha, 255, 0, 0);

            imageView.setColorFilter(glowingRed, PorterDuff.Mode.SRC_ATOP);
        });
        animator.start();

        // Save animator if this is otherIcon
        if (imageView == otherIcon) {
            otherIconAnimator = animator;
        }
    }

    /**
     * Starts a typewriter-style effect to display the given text gradually,
     * one character at a time inside the dialogueTextView.
     *
     * @param text The full text to display with the typewriter effect.
     */
    private void startTypewriterEffect(String text) {
        // Saves the full text to type
        fullTextToType = text;

        // Starts from the beginning of the string
        currentCharIndex = 0;

        // Flags to track whether typing is currently happening
        isTyping = true;

        // Clears any existing text in the TextView
        dialogueTextView.setText("");

        // Defines a new Runnable that will be executed repeatedly to start typing
        typeRunnable = new Runnable() {
            @Override
            public void run() {
                // If not finished typing all characters
                if (currentCharIndex < fullTextToType.length()) {
                    // Append the next character to the TextView
                    dialogueTextView.append(String.valueOf(fullTextToType.charAt(currentCharIndex)));

                    // Moves to the next character
                    currentCharIndex++;

                    // Re-posts the Runnable after a delay to continue the effect
                    // "this" refers to the current Runnable instance
                    textHandler.postDelayed(this, typingSpeed);
                } else {
                    // When all characters have been typed, this stops the typing effect
                    isTyping = false;
                }
            }
        };

        // Starts typing effect immediately
        textHandler.post(typeRunnable);
    }

    /**
     * If user taps mid-typing, the dialogue text is instantly completed.
     */
    private void skipTypewriter() {
        if (isTyping) {
            textHandler.removeCallbacks(typeRunnable);
            dialogueTextView.setText(fullTextToType);
            isTyping = false;
        }
    }

    private int inputAttempts = 0;

    /**
     * Shows a text input prompt and handles submission.
     */
    private void showInputPrompt() {
        userInputEditText.setVisibility(View.VISIBLE);
        submitAnswerButton.setVisibility(View.VISIBLE);
        inputAttempts = 1; // start at 1 so first increment is 2
        Log.d("MainActivity", "Showing input prompt and submit button");

        Map<Integer, String> responseMap = new HashMap<>();
        responseMap.put(2, "Errmm... Nope.");
        responseMap.put(3, "Nuh-uh.");
        responseMap.put(4, "Nein.");
        responseMap.put(5, "Man, you're exhausting...");
        responseMap.put(6, "...");
        responseMap.put(7, "...");
        responseMap.put(8, "....");
        responseMap.put(9, "Not going to lie, I could really go for some chicken wings right now.");
        responseMap.put(10, "Three of them to be exact.");
        responseMap.put(11, "Boop! Got your nose!");

        submitAnswerButton.setOnClickListener(v -> {
            String input = userInputEditText.getText().toString().trim();
            if (input.equals("3")) {
                sceneManager.advanceScene();
                hideInputPrompt();
                showCurrentLine();
            } else {
                inputAttempts++;

                // Loop back to 2 after 11
                if (inputAttempts > 11) {
                    inputAttempts = 2;
                }

                if (responseMap.containsKey(inputAttempts)) {
                    dialogueTextView.setText(responseMap.get(inputAttempts));
                    otherIcon.setImageResource(R.drawable.hansel_talking);

                    if (inputAttempts >= 6 && inputAttempts <= 8) {
                        otherIcon.setImageResource(R.drawable.hansel_normal);
                    }
                } else {
                    dialogueTextView.setText("Hmm... That doesn't sound right. Try again...");
                }
            }
        });
    }

    /**
     * Shows a text input prompt and handles submission.
     */
    private void showInputPrompt1() {
        userInputEditText1.setVisibility(View.VISIBLE);
        submitAnswerButton1.setVisibility(View.VISIBLE);
        inputAttempts = 1;

        Log.d("MainActivity", "Showing input prompt and submit button");

        List<String> responseList = Arrays.asList(
                "It's too hot in here...",
                "She still isn't listening..."
        );

        submitAnswerButton1.setOnClickListener(v -> {
            String input = userInputEditText1.getText().toString().trim();

            if (input.equalsIgnoreCase("Cold")) {
                sceneManager.advanceScene(); // Correct answer
                hideInputPrompt1();
                showCurrentLine();
            } else {
                // Increment first
                inputAttempts++;

                // Special case for "Hot"
                if (input.equalsIgnoreCase("Hot")) {
                    dialogueTextView.setText("That's what she wants to hear...");
                } else {
                    // Loop hint messages
                    int index = (inputAttempts - 2) % responseList.size();
                    if (inputAttempts >= 2) {
                        dialogueTextView.setText(responseList.get(index));
                    }
                }
            }
        });
    }

    /**
     * Hides the input prompt and submit button.
     */
    private void hideInputPrompt() {
        userInputEditText.setVisibility(View.GONE);
        submitAnswerButton.setVisibility(View.GONE);
    }

    /**
     * Hides the input prompt and submit button.
     */
    private void hideInputPrompt1() {
        userInputEditText1.setVisibility(View.GONE);
        submitAnswerButton1.setVisibility(View.GONE);
    }

    /**
     * Loads branching choices from a CSV file into memory.
     *
     * @param fileName CSV file name.
     * @param context  App context.
     */
    private void loadChoicesFromFile(String fileName, Context context) {
        try {
            AssetManager assetManager = context.getAssets();
            InputStream inputStream = assetManager.open(fileName);
            BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
            String line;
            boolean isFirstLine = true;

            choiceData.clear();  // Clear previous choices

            while ((line = reader.readLine()) != null) {
                if (isFirstLine) {
                    isFirstLine = false;
                    continue; // Skip header line
                }
                String[] parts = line.split(",", -1);
                if (parts.length >= 3) {
                    choiceData.add(parts); // Add choices to the list
                }
            }
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Hides the choice buttons.
     */
    private void hideChoices() {
        choiceButton1.setVisibility(View.GONE);
        choiceButton2.setVisibility(View.GONE);
    }

    /**
     * Dynamically loads a drawable image into an ImageView by name.
     *
     * @param imageView The view to load into.
     * @param imageName The name of the image (without extension).
     */
    private void setImage(ImageView imageView, String imageName) {
        // If imageName is null or empty, it skip loading to avoid crashing.
        if (imageName == null || imageName.isEmpty()) return;
        // Removes file extension (Ex: .jpg) from the imageName string, if present.
        // This ensures that only the base name is used when looking up the resource.
        String baseName = imageName.replace(".jpg", "").replace(".png", "");
        // Looks up the resource ID of the image using its base name.
        // getIdentifier() takes the name, resource type ("drawable"), and app's package name.
        int resId = getResources().getIdentifier(baseName, "drawable", getPackageName());
        imageView.setImageResource(resId);
    }
}
