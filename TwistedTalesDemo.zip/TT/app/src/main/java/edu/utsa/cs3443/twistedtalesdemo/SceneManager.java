package edu.utsa.cs3443.twistedtalesdemo;

import android.content.Context;
import android.content.res.AssetManager;
import android.util.Log;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

/**
 * {@code SceneManager} controls the flow of scenes in the visual novel,
 * managing scene progression, dialogue lines, branching paths, and user choices.
 * It loads scenes from CSV files and tracks the current position in the storyline.
 */
public class SceneManager {

    /** Application context used to load resources and access assets. */
    private Context context;

    /** List of scene lines that make up the current scene. */
    private List<SceneLine> currentScene;

    /** Index of the currently displayed dialogue line within the scene. */
    private int currentIndex = 0;

    /** Whether the manager is currently waiting for a player choice before proceeding. */
    private boolean waitingForChoice = false;

    /** Tracks if a story branch has already occurred (prevents re-branching). */
    private boolean hasBranched = false;

    /** Parsed data from the choices CSV file. */
    private List<String[]> choiceData = new ArrayList<>();

    /** File name of the currently loaded scene. */
    private String currentFileName;

    /**
     * Constructs a new {@code SceneManager} with an initial scene loaded.
     *
     * @param context          The application context used to access assets.
     * @param initialFileName  The name of the initial CSV file containing the scene to load.
     */
    public SceneManager(Context context, String initialFileName) {
        this.context = context;
        this.currentFileName = initialFileName;

        loadNeutralScene();
        loadChoices();  // Load choices for branching
    }

    /**
     * Returns the file name of the currently loaded scene.
     *
     * @return The current scene's CSV file name.
     */
    public String getCurrentFileName() {
        return currentFileName;
    }

    /**
     * Loads the list of available choices from "HAGChoices.csv".
     * Each line must have at least 3 comma-separated values to be valid.
     */
    private void loadChoices() {
        try {
            AssetManager assetManager = context.getAssets();
            InputStream inputStream = assetManager.open("HAGChoices.csv");
            BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
            String line;
            boolean isFirstLine = true;
            while ((line = reader.readLine()) != null) {
                if (isFirstLine) {
                    isFirstLine = false;
                    continue;
                }
                String[] parts = line.split(",", -1);
                if (parts.length >= 3) {
                    choiceData.add(parts);
                }
            }
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Retrieves the current {@link SceneLine} being displayed.
     *
     * @return The current scene line, or {@code null} if the index is out of bounds.
     */
    public SceneLine getCurrentLine() {
        if (currentIndex < currentScene.size()) {
            return currentScene.get(currentIndex);
        }
        return null;
    }

    /**
     * Advances the scene to the next line if not waiting on a user choice.
     */
    public void advanceScene() {
        if (!waitingForChoice) {
            currentIndex++;
        }
    }

    /**
     * Determines if the current scene has reached a choice point.
     *
     * @return {@code true} if on the final line of the scene and a branch has not occurred yet.
     */
    public boolean isChoicePoint() {
        return currentIndex == currentScene.size() - 1 && !hasBranched;
    }

    /**
     * Checks whether the end of the scene has been reached.
     *
     * @return {@code true} if there are no more lines to display.
     */
    public boolean isAtEnd() {
        return currentIndex >= currentScene.size();
    }

    /**
     * Loads the default "neutral" scene from the "HAGNeutral.csv" file.
     * This method resets scene position and flags for a fresh start.
     */
    public void loadNeutralScene() {
        currentFileName = "HAGNeutral.csv";
        currentScene = CsvLoader.loadScene(context, currentFileName);
        currentIndex = 0;
        waitingForChoice = false;
        hasBranched = false;
    }

    /**
     * Loads a branching scene path from the specified CSV file.
     * Updates internal state to reflect that a branch has occurred.
     *
     * @param branchFile The file name of the new scene to load.
     */
    public void loadBranch(String branchFile) {
        currentFileName = branchFile;
        currentScene = CsvLoader.loadScene(context, currentFileName);
        currentIndex = 0;
        waitingForChoice = false;
        hasBranched = true;
    }

    /**
     * Pauses scene progression and flags that a choice must be made before continuing.
     */
    public void waitForChoice() {
        waitingForChoice = true;
    }
}
