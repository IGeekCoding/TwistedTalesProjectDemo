package edu.utsa.cs3443.twistedtalesdemo;

import android.content.Context;
import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class CsvFileWriter {

    // Step 1: Get all .csv file names from assets
    public static List<String> getCsvFileNames(Context context) {
        List<String> csvFileNames = new ArrayList<>();
        try {
            String[] allFiles = context.getAssets().list("");
            if (allFiles != null) {
                for (String file : allFiles) {
                    if (file.endsWith(".csv")) {
                        csvFileNames.add(file);
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return csvFileNames;
    }

    // Appends a single filename to the internal CSV log
    public static void appendCsvFileName(Context context, String fileName, String outputFileName) {
        File file = new File(context.getFilesDir(), outputFileName);

        try (FileWriter writer = new FileWriter(file, true)) { // true = append mode
            writer.append(fileName).append("\n");
            writer.flush();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Step 2: Write the list of file names into a new .csv file
    public static void writeCsvFileNamesToCsv(Context context, List<String> fileNames, String newFileName) {
        File newCsvFile = new File(context.getFilesDir(), newFileName); // Internal storage

        try (FileWriter writer = new FileWriter(newCsvFile)) {
            for (String name : fileNames) {
                writer.append(name).append("\n"); // one name per line
            }
            writer.flush();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void logSceneFile(Context context, String sceneFileName) {
        appendCsvFileName(context, sceneFileName, "scene_log.csv");
    }

    // Step 3: Combine both steps into a single call
    public static void generateCsvList(Context context) {
        List<String> csvNames = getCsvFileNames(context);

        // Optional: remove the name of the target file if you don't want it listed
        csvNames.remove("csv_list.csv");

        writeCsvFileNamesToCsv(context, csvNames, "csv_list.csv");
    }
}

