package edu.utsa.cs3443.twistedtalesdemo;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

/**
 * The {@code Continue} class is a transitional activity that checks for saved game progress
 * and directs the user to the appropriate screen. If a saved state is found, it starts
 * {@link MainActivity} to resume the game. Otherwise, it redirects to {@link StoryActivity}
 * to select a new story. This activity immediately finishes after redirection to prevent
 * the user from returning to it via the back button.
 *
 * This activity also ensures that edge-to-edge display behavior is consistent with the rest
 * of the app by applying system window insets to the layout.
 */
public class Continue extends AppCompatActivity {

    /**
     * Called when the activity is starting. This method sets up edge-to-edge layout behavior,
     * checks for saved game progress using shared preferences, and starts the appropriate
     * activity based on whether a saved state exists.
     *
     * @param savedInstanceState If the activity is being re-initialized after previously being
     *                           shut down, this contains the most recent saved state. Otherwise, null.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Enable edge-to-edge layout rendering.
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_continue);

        // Apply system window insets to the main view for proper padding.
        ViewCompat.setOnApplyWindowInsetsListener(
                findViewById(R.id.story_main),
                (v, insets) -> {
                    Insets sys = insets.getInsets(WindowInsetsCompat.Type.systemBars());
                    v.setPadding(sys.left, sys.top, sys.right, sys.bottom);
                    return insets;
                }
        );

        // Check for saved progress in shared preferences.
        SharedPreferences prefs = getSharedPreferences("savegame", MODE_PRIVATE);
        boolean hasSave = prefs.contains("last_scene_id") && prefs.contains("last_choice_text");

        Intent next;
        if (hasSave) {
            // Resume saved game by launching MainActivity.
            next = new Intent(this, MainActivity.class);
            next.putExtra("load_progress", true);
        } else {
            // No saved game found; redirect to StoryActivity for new story selection.
            next = new Intent(this, StoryActivity.class);
        }

        // Start the determined activity and finish this one to prevent navigating back to it.
        startActivity(next);
        finish();
    }
}
