package edu.utsa.cs3443.twistedtalesdemo;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

/**
 * {@code CreditsActivity} displays the credits screen of the application.
 * It sets up the user interface with edge-to-edge support and ensures that
 * the content layout properly respects system UI (e.g., status bar, navigation bar)
 * using window insets.
 */
public class CreditsActivity extends AppCompatActivity {

    /**
     * Called when the activity is starting. This method initializes the layout for the credits
     * screen, enables edge-to-edge display, and applies system window insets to ensure
     * appropriate padding and layout behavior across different screen configurations.
     *
     * @param savedInstanceState If the activity is being re-initialized after previously being
     *                           shut down, this contains the most recent saved state. Otherwise, null.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Enable edge-to-edge layout rendering.
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_credits);

        // Apply system window insets to the main layout to prevent overlap with system bars.
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
}
