package edu.utsa.cs3443.twistedtalesdemo;

import android.content.Context;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

/**
 * The {@code CsvFileReader} class provides utility methods for reading CSV files
 * related to the application's internal data, such as logging scene transitions.
 */
public class CsvFileReader {

    /**
     * Reads the most recent scene file name from the {@code scene_log.csv} file stored in internal storage.
     * <p>
     * This method assumes that each line in the file corresponds to a logged scene, and the
     * last line represents the most recent scene. If the file does not exist, is empty,
     * or an error occurs while reading, the method returns {@code null}.
     *
     * @param context The application context used to access the internal file directory.
     * @return The name of the most recent scene file, or {@code null} if unavailable.
     */
    public static String readMostRecentSceneFile(Context context) {
        File logFile = new File(context.getFilesDir(), "scene_log.csv");

        String mostRecentSceneFile = null;

        try (BufferedReader reader = new BufferedReader(new FileReader(logFile))) {
            String line;
            String lastLine = null;

            // Read the file line by line, storing only the last line
            while ((line = reader.readLine()) != null) {
                lastLine = line;
            }

            // The lastLine is now the most recent scene file written
            mostRecentSceneFile = lastLine;
        } catch (IOException e) {
            e.printStackTrace();
        }

        return mostRecentSceneFile;
    }
}
