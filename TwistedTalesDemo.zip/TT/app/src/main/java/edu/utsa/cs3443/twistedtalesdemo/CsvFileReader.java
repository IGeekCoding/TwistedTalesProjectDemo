package edu.utsa.cs3443.twistedtalesdemo;

import android.content.Context;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

public class CsvFileReader {

    /**
     * Reads the most recent scene file name from the scene_log.csv file.
     * The most recent entry is assumed to be the last line written to the file.
     *
     * @param context The context used to access internal storage.
     * @return The most recent scene file name, or null if the file is empty or an error occurs.
     */
    public static String readMostRecentSceneFile(Context context) {
        File logFile = new File(context.getFilesDir(), "scene_log.csv");

        String mostRecentSceneFile = null;

        try (BufferedReader reader = new BufferedReader(new FileReader(logFile))) {
            String line;
            String lastLine = null;

            // Read the file line by line, storing only the last line
            while ((line = reader.readLine()) != null) {
                lastLine = line;
            }

            // The lastLine is now the most recent scene file written
            mostRecentSceneFile = lastLine;
        } catch (IOException e) {
            e.printStackTrace();
        }

        return mostRecentSceneFile;
    }
}
