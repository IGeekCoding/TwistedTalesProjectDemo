package edu.utsa.cs3443.twistedtalesdemo;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

/**
 * {@code SettingsActivity} provides the user interface for adjusting the application's settings.
 * It ensures that the layout respects system UI elements such as status bars and navigation bars
 * by applying appropriate padding.
 */
public class SettingsActivity extends AppCompatActivity {

    /**
     * Called when the activity is created. This method sets up the UI and ensures that the layout
     * takes into account the system bars (status bar, navigation bar) by applying window insets.
     *
     * @param savedInstanceState A bundle containing the activity's previously saved state. If no state exists, this is null.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this); // Enable edge-to-edge layout for immersive experience.
        setContentView(R.layout.activity_settings); // Set the layout for the settings screen.

        // Apply padding to the root view based on system bars (status and navigation bars).
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
}
