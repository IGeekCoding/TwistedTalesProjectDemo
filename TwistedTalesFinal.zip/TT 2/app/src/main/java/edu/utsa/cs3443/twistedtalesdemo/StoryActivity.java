package edu.utsa.cs3443.twistedtalesdemo;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

/**
 * {@code StoryActivity} represents the screen where the user can choose which story to play.
 * This screen presents options to select different stories (e.g., Hansel and Gretel, Little Red Riding Hood).
 * It ensures that the layout takes into account system UI elements such as status bars and navigation bars.
 */
public class StoryActivity extends AppCompatActivity {

    /**
     * Called when the activity is created. It sets up the layout, applies padding for system UI elements,
     * and initializes the buttons for selecting different stories.
     *
     * @param savedInstanceState A bundle containing the activity's previously saved state. If no state exists, this is null.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this); // Enable edge-to-edge layout for an immersive experience.
        setContentView(R.layout.activity_story); // Set the layout for the story selection screen.

        // Apply window insets to ensure padding is applied for system bars (status and navigation bars).
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.story_main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Set up "Hansel and Gretel" button to start the corresponding story.
        Button btnHanselGretel = findViewById(R.id.btnHanselGretel);
        btnHanselGretel.setOnClickListener(v -> {
            Intent intent = new Intent(this, MainActivity.class);
            intent.putExtra("scene_file", "HAGNeutral.csv"); // Hansel and Gretel default scene file
            startActivity(intent);
        });

        // Set up "Little Red Riding Hood" button to start the corresponding story.
        Button btnLittleRed = findViewById(R.id.btnLittleRed);
        btnLittleRed.setOnClickListener(v -> {
            Intent intent = new Intent(this, MainActivity.class);
            intent.putExtra("scene_file", "LRHNeutral.csv"); // Little Red Riding Hood CSV file
            startActivity(intent);
        });
    }
}
