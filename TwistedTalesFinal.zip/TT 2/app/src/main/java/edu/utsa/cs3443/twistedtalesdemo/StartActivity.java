package edu.utsa.cs3443.twistedtalesdemo;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

/**
 * {@code StartActivity} represents the starting screen of the application.
 * This screen provides options to either start a new game or continue an existing game.
 * It also ensures that the layout accounts for system UI elements such as status bars and navigation bars.
 */
public class StartActivity extends AppCompatActivity {

    /**
     * Called when the activity is created. It sets up the layout, applies padding for system UI elements,
     * and initializes the buttons to start a new game or continue an existing game.
     *
     * @param savedInstanceState A bundle containing the activity's previously saved state. If no state exists, this is null.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this); // Enable edge-to-edge layout for an immersive experience.
        setContentView(R.layout.activity_start); // Set the layout for the start screen.

        // Apply window insets to ensure padding is applied for system bars (status and navigation bars).
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Set up "New Game" button to launch StoryActivity for a fresh game start.
        Button btnNewGame = findViewById(R.id.btnNewGame);
        btnNewGame.setOnClickListener(v ->
                startActivity(new Intent(this, StoryActivity.class)) // Launch the StoryActivity for a new game
        );

        // Set up "Continue Game" button to load the most recent game state.
        Button btnHanselGretel = findViewById(R.id.btnContinueGame);
        btnHanselGretel.setOnClickListener(v -> {
            Intent intent = new Intent(this, MainActivity.class);
            // Read the most recent scene file from the scene log.
            String mostRecentSceneFile = CsvFileReader.readMostRecentSceneFile(this);
            if (mostRecentSceneFile != null) {
                // If a scene file is found, pass it to MainActivity for continuation.
                intent.putExtra("scene_file", mostRecentSceneFile);
                startActivity(intent);
            } else {
                // Log or show an error message if no scene file is found.
                System.out.println("No scene file found or error reading log.");
            }

            // Start MainActivity to continue the game.
            startActivity(intent);
        });
    }
}
