package edu.utsa.cs3443.twistedtalesdemo;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

/**
 * {@code HomeActivity} serves as the main entry screen of the application.
 * It provides navigation buttons for starting the game, accessing settings, and viewing credits.
 */
public class HomeActivity extends AppCompatActivity {

    /** Button to navigate to the start or story selection screen. */
    Button btnStart;

    /** Button to open the settings screen. */
    Button btnSettings;

    /** Button to view the application credits. */
    Button btnCredits;

    /**
     * Called when the activity is first created.
     * Initializes the UI components and sets up navigation button listeners.
     *
     * @param savedInstanceState If the activity is being re-initialized after previously being
     *                           shut down, this contains the most recent saved state. Otherwise, null.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        // Initialize buttons by their resource IDs
        btnStart = findViewById(R.id.btnStart);
        btnSettings = findViewById(R.id.btnSettings);
        btnCredits = findViewById(R.id.btnCredits);

        // Set click listeners for navigation
        btnStart.setOnClickListener(v -> startActivity(new Intent(this, StartActivity.class)));
        btnSettings.setOnClickListener(v -> startActivity(new Intent(this, SettingsActivity.class)));
        btnCredits.setOnClickListener(v -> startActivity(new Intent(this, CreditsActivity.class)));
    }
}
