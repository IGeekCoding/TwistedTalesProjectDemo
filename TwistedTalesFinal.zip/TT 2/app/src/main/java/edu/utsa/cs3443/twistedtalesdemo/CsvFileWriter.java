package edu.utsa.cs3443.twistedtalesdemo;

import android.content.Context;
import java.io.*;
import java.util.ArrayList;
import java.util.List;

/**
 * {@code CsvFileWriter} provides utility methods for handling CSV file operations such as
 * retrieving, writing, and appending filenames. These operations are primarily used for
 * logging and organizing CSV assets related to story scenes or configuration in the application.
 */
public class CsvFileWriter {

    /**
     * Retrieves all CSV file names located in the application's assets directory.
     *
     * @param context The application context used to access the assets.
     * @return A list of CSV file names found in the assets folder.
     */
    public static List<String> getCsvFileNames(Context context) {
        List<String> csvFileNames = new ArrayList<>();
        try {
            String[] allFiles = context.getAssets().list("");
            if (allFiles != null) {
                for (String file : allFiles) {
                    if (file.endsWith(".csv")) {
                        csvFileNames.add(file);
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return csvFileNames;
    }

    /**
     * Appends a single filename to a specified CSV file located in internal storage.
     * This is typically used to log activity, such as a visited scene.
     *
     * @param context       The application context used to access internal storage.
     * @param fileName      The name of the file to append (typically a scene file).
     * @param outputFileName The name of the CSV log file to write into.
     */
    public static void appendCsvFileName(Context context, String fileName, String outputFileName) {
        File file = new File(context.getFilesDir(), outputFileName);

        try (FileWriter writer = new FileWriter(file, true)) { // true = append mode
            writer.append(fileName).append("\n");
            writer.flush();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Writes a list of file names to a new CSV file in the application's internal storage.
     * Each filename will be written on a separate line.
     *
     * @param context     The application context used to access internal storage.
     * @param fileNames   The list of file names to write.
     * @param newFileName The name of the new CSV file to create.
     */
    public static void writeCsvFileNamesToCsv(Context context, List<String> fileNames, String newFileName) {
        File newCsvFile = new File(context.getFilesDir(), newFileName);

        try (FileWriter writer = new FileWriter(newCsvFile)) {
            for (String name : fileNames) {
                writer.append(name).append("\n");
            }
            writer.flush();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Logs a scene file name to the default {@code scene_log.csv} file.
     * This is a convenience method that wraps {@link #appendCsvFileName}.
     *
     * @param context        The application context used to access internal storage.
     * @param sceneFileName  The scene file name to log.
     */
    public static void logSceneFile(Context context, String sceneFileName) {
        appendCsvFileName(context, sceneFileName, "scene_log.csv");
    }

    /**
     * Combines the steps of retrieving CSV files from assets and writing them
     * to a CSV list file in internal storage. Automatically excludes {@code csv_list.csv}
     * from the output list if it exists.
     *
     * @param context The application context used to perform asset and file operations.
     */
    public static void generateCsvList(Context context) {
        List<String> csvNames = getCsvFileNames(context);

        // Optional: remove the name of the target file if you don't want it listed
        csvNames.remove("csv_list.csv");

        writeCsvFileNamesToCsv(context, csvNames, "csv_list.csv");
    }
}
