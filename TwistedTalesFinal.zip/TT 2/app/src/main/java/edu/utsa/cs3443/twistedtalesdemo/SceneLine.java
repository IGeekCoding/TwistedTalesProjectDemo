package edu.utsa.cs3443.twistedtalesdemo;

/**
 * Represents a single line or moment in a visual novel scene.
 * <p>
 * A {@code SceneLine} holds all the visual and textual information needed to render
 * a point in the story: dialogue, character visuals, and background imagery.
 * This class supports scene navigation and branching by its {@code sceneId}.
 */
public class SceneLine {

    /** Unique identifier for this scene line, used for branching and progression tracking. */
    public String sceneId;

    /** The name of the character who is speaking in this line. */
    public String name;

    /** The dialogue or narration text to display for this scene line. */
    public String dialogue;

    /** The file name or identifier for the main character icon (typically the speaker). */
    public String mainIcon;

    /** The file name or identifier for the secondary character icon (optional). */
    public String otherIcon;

    /** The file name or identifier for the background image of the scene. */
    public String background;

    /**
     * Constructs a {@code SceneLine} with full visual and narrative information.
     *
     * @param sceneId    Unique ID for the scene line, used for branching logic.
     * @param name       Name of the speaking character.
     * @param dialogue   Dialogue or narration text to display.
     * @param mainIcon   Main character icon image identifier.
     * @param otherIcon  Optional secondary character icon image identifier.
     * @param background Background image identifier for the scene.
     */
    public SceneLine(String sceneId, String name, String dialogue, String mainIcon, String otherIcon, String background) {
        this.sceneId = sceneId;
        this.name = name;
        this.dialogue = dialogue;
        this.mainIcon = mainIcon;
        this.otherIcon = otherIcon;
        this.background = background;
    }
}
